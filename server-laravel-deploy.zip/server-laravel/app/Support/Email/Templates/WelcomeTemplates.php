<?php

namespace App\Support\Email\Templates;

use App\Support\Email\EmailShared;

class WelcomeTemplates
{
    /**
     * @param  array<string, mixed>  $options
     * @return array{subject: string, html: string, text: string}
     */
    public static function welcome(string $name, array $options = []): array
    {
        $brand = EmailShared::brandLinks([
            'brandName' => $options['brandName'] ?? null,
            'brandSiteUrl' => $options['brandSiteUrl'] ?? null,
            'bookingSiteUrl' => $options['bookingSiteUrl'] ?? null,
        ]);
        $html = EmailShared::layout(
            'Welcome to ' . EmailShared::escapeHtml($brand['brandName']),
            EmailShared::escapeHtml($name),
            EmailShared::p('Your account is ready. Thank you for joining <strong>' . EmailShared::escapeHtml($brand['brandName']) . '</strong> — we’re delighted to have you with us.')
                . EmailShared::p('When you’re ready for a countryside escape, you can browse live availability and book direct for the best rate.')
                . EmailShared::emailButton($brand['bookingSiteUrl'], 'Explore stays →')
                . EmailShared::textLinks([
                    ['url' => $brand['brandSiteUrl'], 'label' => "Explore {$brand['brandName']} →"],
                    ['url' => $brand['bookingSiteUrl'], 'label' => 'Visit our booking website →'],
                ]),
            'Questions? Contact us through ' . EmailShared::escapeHtml($brand['bookingSiteUrl']) . '.',
            ['preheader' => "Your {$brand['brandName']} account is ready"]
        );

        return EmailShared::rendered(
            EmailShared::safeSubjectText('Welcome to ' . $brand['brandName']),
            $html,
            implode("\n", [
                "Hello {$name},",
                '',
                "Your account is ready. Thank you for joining {$brand['brandName']} — we're delighted to have you with us.",
                '',
                "When you're ready for a countryside escape, browse live availability and book direct for the best rate:",
                $brand['bookingSiteUrl'],
                '',
                'Warm wishes,',
                "The {$brand['brandName']} Team",
            ])
        );
    }
}
