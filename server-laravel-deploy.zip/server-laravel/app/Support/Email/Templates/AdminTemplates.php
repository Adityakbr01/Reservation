<?php

namespace App\Support\Email\Templates;

use App\Support\Email\EmailShared;

class AdminTemplates
{
    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function adminAlert(array $ctx, string $subject): array
    {
        $html = EmailShared::layout(
            EmailShared::escapeHtml((string) $ctx['headline']),
            'team',
            EmailShared::p('Booking ' . EmailShared::refPill((string) $ctx['bookingReference']))
                . EmailShared::infoCard(EmailShared::p(EmailShared::escapeHtml((string) $ctx['detail'])))
                . EmailShared::emailButton((string) $ctx['adminUrl'], 'Open in admin →'),
            'Open in admin: ' . EmailShared::escapeHtml((string) $ctx['adminUrl']),
            ['preheader' => "{$ctx['headline']}: {$ctx['bookingReference']}"]
        );

        return EmailShared::rendered(
            EmailShared::safeSubjectText("{$subject} — {$ctx['bookingReference']}"),
            $html,
            implode("\n", [
                'Hello team,',
                '',
                (string) $ctx['headline'],
                "Booking {$ctx['bookingReference']}: {$ctx['detail']}",
                '',
                "Open in admin: {$ctx['adminUrl']}",
            ])
        );
    }
}
