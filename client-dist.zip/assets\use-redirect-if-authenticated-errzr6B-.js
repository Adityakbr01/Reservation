import{a as e,n as t,t as n}from"./compiler-runtime-BNvLG3sJ.js";import{i as r}from"./label-CscmWOKj.js";import{c as i,l as a,n as o}from"./chunk-6KYCQHYJ-D8cPE0vb.js";import{o as s,q as c}from"./button-C_Lake3C.js";var l={name:`arrow-left`,size:24,node:[[`path`,{d:`m12 19-7-7 7-7`,key:`1l729n`}],[`path`,{d:`M19 12H5`,key:`x3x0zl`}]]};l.node;var u=s(l),d=`#version 300 es
precision mediump float;

layout(location = 0) in vec4 a_position;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_imageAspectRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;
uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

out vec2 v_objectUV;
out vec2 v_objectBoxSize;
out vec2 v_responsiveUV;
out vec2 v_responsiveBoxGivenSize;
out vec2 v_patternUV;
out vec2 v_patternBoxSize;
out vec2 v_imageUV;

vec3 getBoxSize(float boxRatio, vec2 givenBoxSize) {
  vec2 box = vec2(0.);
  // fit = none
  box.x = boxRatio * min(givenBoxSize.x / boxRatio, givenBoxSize.y);
  float noFitBoxWidth = box.x;
  if (u_fit == 1.) { // fit = contain
    box.x = boxRatio * min(u_resolution.x / boxRatio, u_resolution.y);
  } else if (u_fit == 2.) { // fit = cover
    box.x = boxRatio * max(u_resolution.x / boxRatio, u_resolution.y);
  }
  box.y = box.x / boxRatio;
  return vec3(box, noFitBoxWidth);
}

void main() {
  gl_Position = a_position;

  vec2 uv = gl_Position.xy * .5;
  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  vec2 givenBoxSize = vec2(u_worldWidth, u_worldHeight);
  givenBoxSize = max(givenBoxSize, vec2(1.)) * u_pixelRatio;
  float r = u_rotation * 3.14159265358979323846 / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);


  // ===================================================

  float fixedRatio = 1.;
  vec2 fixedRatioBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );

  v_objectBoxSize = getBoxSize(fixedRatio, fixedRatioBoxGivenSize).xy;
  vec2 objectWorldScale = u_resolution.xy / v_objectBoxSize;

  v_objectUV = uv;
  v_objectUV *= objectWorldScale;
  v_objectUV += boxOrigin * (objectWorldScale - 1.);
  v_objectUV += graphicOffset;
  v_objectUV /= u_scale;
  v_objectUV = graphicRotation * v_objectUV;

  // ===================================================

  v_responsiveBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  float responsiveRatio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
  vec2 responsiveBoxSize = getBoxSize(responsiveRatio, v_responsiveBoxGivenSize).xy;
  vec2 responsiveBoxScale = u_resolution.xy / responsiveBoxSize;

  #ifdef ADD_HELPERS
  v_responsiveHelperBox = uv;
  v_responsiveHelperBox *= responsiveBoxScale;
  v_responsiveHelperBox += boxOrigin * (responsiveBoxScale - 1.);
  #endif

  v_responsiveUV = uv;
  v_responsiveUV *= responsiveBoxScale;
  v_responsiveUV += boxOrigin * (responsiveBoxScale - 1.);
  v_responsiveUV += graphicOffset;
  v_responsiveUV /= u_scale;
  v_responsiveUV.x *= responsiveRatio;
  v_responsiveUV = graphicRotation * v_responsiveUV;
  v_responsiveUV.x /= responsiveRatio;

  // ===================================================

  float patternBoxRatio = givenBoxSize.x / givenBoxSize.y;
  vec2 patternBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  patternBoxRatio = patternBoxGivenSize.x / patternBoxGivenSize.y;

  vec3 boxSizeData = getBoxSize(patternBoxRatio, patternBoxGivenSize);
  v_patternBoxSize = boxSizeData.xy;
  float patternBoxNoFitBoxWidth = boxSizeData.z;
  vec2 patternBoxScale = u_resolution.xy / v_patternBoxSize;

  v_patternUV = uv;
  v_patternUV += graphicOffset / patternBoxScale;
  v_patternUV += boxOrigin;
  v_patternUV -= boxOrigin / patternBoxScale;
  v_patternUV *= u_resolution.xy;
  v_patternUV /= u_pixelRatio;
  if (u_fit > 0.) {
    v_patternUV *= (patternBoxNoFitBoxWidth / v_patternBoxSize.x);
  }
  v_patternUV /= u_scale;
  v_patternUV = graphicRotation * v_patternUV;
  v_patternUV += boxOrigin / patternBoxScale;
  v_patternUV -= boxOrigin;
  // x100 is a default multiplier between vertex and fragmant shaders
  // we use it to avoid UV presision issues
  v_patternUV *= .01;

  // ===================================================

  vec2 imageBoxSize;
  if (u_fit == 1.) { // contain
    imageBoxSize.x = min(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else if (u_fit == 2.) { // cover
    imageBoxSize.x = max(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else {
    imageBoxSize.x = min(10.0, 10.0 / u_imageAspectRatio * u_imageAspectRatio);
  }
  imageBoxSize.y = imageBoxSize.x / u_imageAspectRatio;
  vec2 imageBoxScale = u_resolution.xy / imageBoxSize;

  v_imageUV = uv;
  v_imageUV *= imageBoxScale;
  v_imageUV += boxOrigin * (imageBoxScale - 1.);
  v_imageUV += graphicOffset;
  v_imageUV /= u_scale;
  v_imageUV.x *= u_imageAspectRatio;
  v_imageUV = graphicRotation * v_imageUV;
  v_imageUV.x /= u_imageAspectRatio;

  v_imageUV += .5;
  v_imageUV.y = 1. - v_imageUV.y;
}`,f=8294400,p=class{parentElement;canvasElement;gl;program=null;uniformLocations={};fragmentShader;rafId=null;lastRenderTime=0;currentFrame=0;speed=0;currentSpeed=0;providedUniforms;mipmaps=[];hasBeenDisposed=!1;resolutionChanged=!0;textures=new Map;minPixelRatio;maxPixelCount;isSafari=_();uniformCache={};textureUnitMap=new Map;ownerDocument;constructor(e,t,n,r,i=0,a=0,o=2,s=f,c=[]){if(e?.nodeType===1)this.parentElement=e;else throw Error(`Paper Shaders: parent element must be an HTMLElement`);if(this.ownerDocument=e.ownerDocument,!this.ownerDocument.querySelector(`style[data-paper-shader]`)){let e=this.ownerDocument.createElement(`style`);e.innerHTML=g,e.setAttribute(`data-paper-shader`,``),this.ownerDocument.head.prepend(e)}let l=this.ownerDocument.createElement(`canvas`);this.canvasElement=l,this.parentElement.prepend(l),this.fragmentShader=t,this.providedUniforms=n,this.mipmaps=c,this.currentFrame=a,this.minPixelRatio=o,this.maxPixelCount=s;let u=l.getContext(`webgl2`,{antialias:!1,depth:!1,stencil:!1,...r});if(!u)throw Error(`Paper Shaders: WebGL is not supported in this browser`);this.gl=u,this.initProgram(),this.setupPositionAttribute(),this.setupUniforms(),this.setUniformValues(this.providedUniforms),this.setupResizeObserver(),visualViewport?.addEventListener(`resize`,this.handleVisualViewportChange),this.setupIntersectionObserver(),this.setSpeed(i),this.parentElement.setAttribute(`data-paper-shader`,``),this.parentElement.paperShaderMount=this,this.ownerDocument.addEventListener(`visibilitychange`,this.handleDocumentVisibilityChange)}initProgram=()=>{let e=h(this.gl,d,this.fragmentShader);e&&(this.program=e,this.gl.useProgram(e))};setupPositionAttribute=()=>{let e=this.gl.getAttribLocation(this.program,`a_position`),t=this.gl.createBuffer();this.gl.bindBuffer(this.gl.ARRAY_BUFFER,t),this.gl.bufferData(this.gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),this.gl.STATIC_DRAW),this.gl.enableVertexAttribArray(e),this.gl.vertexAttribPointer(e,2,this.gl.FLOAT,!1,0,0)};setupUniforms=()=>{let e={u_time:this.gl.getUniformLocation(this.program,`u_time`),u_pixelRatio:this.gl.getUniformLocation(this.program,`u_pixelRatio`),u_resolution:this.gl.getUniformLocation(this.program,`u_resolution`)};Object.entries(this.providedUniforms).forEach(([t,n])=>{if(e[t]=this.gl.getUniformLocation(this.program,t),n instanceof HTMLImageElement){let n=`${t}AspectRatio`;e[n]=this.gl.getUniformLocation(this.program,n)}}),this.uniformLocations=e};renderScale=1;parentWidth=0;parentHeight=0;parentDevicePixelWidth=0;parentDevicePixelHeight=0;devicePixelsSupported=!1;intersectionObserver=null;isInViewport=!0;resizeObserver=null;setupResizeObserver=()=>{this.resizeObserver=new ResizeObserver(([e])=>{if(e?.borderBoxSize[0]){let t=e.devicePixelContentBoxSize?.[0];t!==void 0&&(this.devicePixelsSupported=!0,this.parentDevicePixelWidth=t.inlineSize,this.parentDevicePixelHeight=t.blockSize),this.parentWidth=e.borderBoxSize[0].inlineSize,this.parentHeight=e.borderBoxSize[0].blockSize}this.handleResize()}),this.resizeObserver.observe(this.parentElement)};setupIntersectionObserver=()=>{let e=this.ownerDocument.defaultView;e?.IntersectionObserver&&(this.intersectionObserver=new e.IntersectionObserver(([e])=>{this.isInViewport=e?.isIntersecting??!0,this.updateCurrentSpeed()}),this.intersectionObserver.observe(this.parentElement))};handleVisualViewportChange=()=>{this.resizeObserver?.disconnect(),this.setupResizeObserver()};handleResize=()=>{let e=0,t=0,n=Math.max(1,window.devicePixelRatio),r=visualViewport?.scale??1;if(this.devicePixelsSupported){let i=Math.max(1,this.minPixelRatio/n);e=this.parentDevicePixelWidth*i*r,t=this.parentDevicePixelHeight*i*r}else{let i=Math.max(n,this.minPixelRatio)*r;if(this.isSafari){let e=v(this.ownerDocument);i*=Math.max(1,e)}e=Math.round(this.parentWidth)*i,t=Math.round(this.parentHeight)*i}let i=Math.sqrt(this.maxPixelCount)/Math.sqrt(e*t),a=Math.min(1,i),o=Math.round(e*a),s=Math.round(t*a),c=o/Math.round(this.parentWidth);(this.canvasElement.width!==o||this.canvasElement.height!==s||this.renderScale!==c)&&(this.renderScale=c,this.canvasElement.width=o,this.canvasElement.height=s,this.resolutionChanged=!0,this.gl.viewport(0,0,this.gl.canvas.width,this.gl.canvas.height),this.render(performance.now()))};render=e=>{if(this.hasBeenDisposed)return;if(this.program===null){console.warn(`Tried to render before program or gl was initialized`);return}let t=e-this.lastRenderTime;this.lastRenderTime=e,this.currentSpeed!==0&&(this.currentFrame+=t*this.currentSpeed),this.gl.clear(this.gl.COLOR_BUFFER_BIT),this.gl.uniform1f(this.uniformLocations.u_time,this.currentFrame*.001),this.resolutionChanged&&=(this.gl.uniform2f(this.uniformLocations.u_resolution,this.gl.canvas.width,this.gl.canvas.height),this.gl.uniform1f(this.uniformLocations.u_pixelRatio,this.renderScale),!1),this.gl.drawArrays(this.gl.TRIANGLES,0,6),this.currentSpeed===0?this.rafId=null:this.requestRender()};requestRender=()=>{this.rafId!==null&&cancelAnimationFrame(this.rafId),this.rafId=requestAnimationFrame(this.render)};setTextureUniform=(e,t)=>{if(!t.complete||t.naturalWidth===0)throw Error(`Paper Shaders: image for uniform ${e} must be fully loaded`);let n=this.textures.get(e);n&&this.gl.deleteTexture(n),this.textureUnitMap.has(e)||this.textureUnitMap.set(e,this.textureUnitMap.size);let r=this.textureUnitMap.get(e);this.gl.activeTexture(this.gl.TEXTURE0+r);let i=this.gl.createTexture();this.gl.bindTexture(this.gl.TEXTURE_2D,i),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_S,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_T,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MAG_FILTER,this.gl.LINEAR),this.gl.texImage2D(this.gl.TEXTURE_2D,0,this.gl.RGBA,this.gl.RGBA,this.gl.UNSIGNED_BYTE,t),this.mipmaps.includes(e)&&(this.gl.generateMipmap(this.gl.TEXTURE_2D),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR_MIPMAP_LINEAR));let a=this.gl.getError();if(a!==this.gl.NO_ERROR||i===null){console.error(`Paper Shaders: WebGL error when uploading texture:`,a);return}this.textures.set(e,i);let o=this.uniformLocations[e];if(o){this.gl.uniform1i(o,r);let n=`${e}AspectRatio`,i=this.uniformLocations[n];if(i){let e=t.naturalWidth/t.naturalHeight;this.gl.uniform1f(i,e)}}};areUniformValuesEqual=(e,t)=>e===t?!0:Array.isArray(e)&&Array.isArray(t)&&e.length===t.length?e.every((e,n)=>this.areUniformValuesEqual(e,t[n])):!1;setUniformValues=e=>{Object.entries(e).forEach(([e,t])=>{let n=t;if(t instanceof HTMLImageElement&&(n=`${t.src.slice(0,200)}|${t.naturalWidth}x${t.naturalHeight}`),this.areUniformValuesEqual(this.uniformCache[e],n))return;this.uniformCache[e]=n;let r=this.uniformLocations[e];if(!r)console.warn(`Uniform location for ${e} not found`);else if(t instanceof HTMLImageElement)this.setTextureUniform(e,t);else if(Array.isArray(t)){let n=null,i=null;if(t[0]!==void 0&&Array.isArray(t[0])){let r=t[0].length;if(t.every(e=>e.length===r))n=t.flat(),i=r;else{console.warn(`All child arrays must be the same length for ${e}`);return}}else n=t,i=n.length;switch(i){case 2:this.gl.uniform2fv(r,n);break;case 3:this.gl.uniform3fv(r,n);break;case 4:this.gl.uniform4fv(r,n);break;case 9:this.gl.uniformMatrix3fv(r,!1,n);break;case 16:this.gl.uniformMatrix4fv(r,!1,n);break;default:console.warn(`Unsupported uniform array length: ${i}`)}}else typeof t==`number`?this.gl.uniform1f(r,t):typeof t==`boolean`?this.gl.uniform1i(r,+!!t):console.warn(`Unsupported uniform type for ${e}: ${typeof t}`)})};getCurrentFrame=()=>this.currentFrame;setFrame=e=>{this.currentFrame=e,this.lastRenderTime=performance.now(),this.renderUnlessAnimating()};setSpeed=(e=1)=>{this.speed=e,this.updateCurrentSpeed()};updateCurrentSpeed=()=>{this.setCurrentSpeed(this.ownerDocument.hidden||!this.isInViewport?0:this.speed)};setCurrentSpeed=e=>{this.currentSpeed=e,this.rafId===null&&e!==0&&(this.lastRenderTime=performance.now(),this.rafId=requestAnimationFrame(this.render)),this.rafId!==null&&e===0&&(cancelAnimationFrame(this.rafId),this.rafId=null)};setMaxPixelCount=(e=f)=>{this.maxPixelCount=e,this.handleResize()};setMinPixelRatio=(e=2)=>{this.minPixelRatio=e,this.handleResize()};setUniforms=e=>{this.setUniformValues(e),this.providedUniforms={...this.providedUniforms,...e},this.renderUnlessAnimating()};renderUnlessAnimating=()=>{this.rafId===null&&this.render(performance.now())};handleDocumentVisibilityChange=()=>{this.updateCurrentSpeed()};dispose=()=>{this.hasBeenDisposed=!0,this.rafId!==null&&(cancelAnimationFrame(this.rafId),this.rafId=null),this.gl&&this.program&&(this.textures.forEach(e=>{this.gl.deleteTexture(e)}),this.textures.clear(),this.gl.deleteProgram(this.program),this.program=null,this.gl.bindBuffer(this.gl.ARRAY_BUFFER,null),this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER,null),this.gl.bindRenderbuffer(this.gl.RENDERBUFFER,null),this.gl.bindFramebuffer(this.gl.FRAMEBUFFER,null),this.gl.getError()),this.gl.getExtension(`WEBGL_lose_context`)?.loseContext(),this.resizeObserver&&=(this.resizeObserver.disconnect(),null),this.intersectionObserver&&=(this.intersectionObserver.disconnect(),null),visualViewport?.removeEventListener(`resize`,this.handleVisualViewportChange),this.ownerDocument.removeEventListener(`visibilitychange`,this.handleDocumentVisibilityChange),this.uniformLocations={},this.canvasElement.remove(),delete this.parentElement.paperShaderMount}};function m(e,t,n){let r=e.createShader(t);return r?(e.shaderSource(r,n),e.compileShader(r),e.getShaderParameter(r,e.COMPILE_STATUS)?r:(console.error(`An error occurred compiling the shaders: `+e.getShaderInfoLog(r)),e.deleteShader(r),null)):null}function h(e,t,n){let r=e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT),i=r?r.precision:null;i&&i<23&&(t=t.replace(/precision\s+(lowp|mediump)\s+float;/g,`precision highp float;`),n=n.replace(/precision\s+(lowp|mediump)\s+float/g,`precision highp float`).replace(/\b(uniform|varying|attribute)\s+(lowp|mediump)\s+(\w+)/g,`$1 highp $3`));let a=m(e,e.VERTEX_SHADER,t),o=m(e,e.FRAGMENT_SHADER,n);if(!a||!o)return null;let s=e.createProgram();return s?(e.attachShader(s,a),e.attachShader(s,o),e.linkProgram(s),e.getProgramParameter(s,e.LINK_STATUS)?(e.detachShader(s,a),e.detachShader(s,o),e.deleteShader(a),e.deleteShader(o),s):(console.error(`Unable to initialize the shader program: `+e.getProgramInfoLog(s)),e.deleteProgram(s),e.deleteShader(a),e.deleteShader(o),null)):null}var g=`@layer paper-shaders {
  :where([data-paper-shader]) {
    isolation: isolate;
    position: relative;

    & canvas {
      contain: strict;
      display: block;
      position: absolute;
      inset: 0;
      z-index: -1;
      width: 100%;
      height: 100%;
      border-radius: inherit;
      corner-shape: inherit;
    }
  }
}`;function _(){let e=navigator.userAgent.toLowerCase();return e.includes(`safari`)&&!e.includes(`chrome`)&&!e.includes(`android`)}function v(e){let t=visualViewport?.scale??1,n=visualViewport?.width??window.innerWidth,r=window.innerWidth-e.documentElement.clientWidth,i=t*n+r,a=outerWidth/i,o=Math.round(100*a);return o%5==0?o/100:o===33?1/3:o===67?2/3:o===133?4/3:a}var y={fit:`contain`,scale:1,rotation:0,offsetX:0,offsetY:0,originX:.5,originY:.5,worldWidth:0,worldHeight:0},b={none:0,contain:1,cover:2},x=`#version 300 es
precision mediump float;

uniform float u_time;

uniform vec4 u_colorBack;
uniform vec4 u_colorHighlight;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;

uniform float u_size;
uniform float u_highlights;
uniform float u_layering;
uniform float u_edges;
uniform float u_caustic;
uniform float u_waves;

in vec2 v_imageUV;

out vec4 fragColor;


#define TWO_PI 6.28318530718
#define PI 3.14159265358979323846


vec2 rotate(vec2 uv, float th) {
  return mat2(cos(th), sin(th), -sin(th), cos(th)) * uv;
}


vec3 permute(vec3 x) { return mod(((x * 34.0) + 1.0) * x, 289.0); }
float snoise(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
    -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1;
  i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0))
    + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy),
      dot(x12.zw, x12.zw)), 0.0);
  m = m * m;
  m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}


float getUvFrame(vec2 uv) {
  float aax = 2. * fwidth(uv.x);
  float aay = 2. * fwidth(uv.y);

  float left   = smoothstep(0., aax, uv.x);
  float right = 1.0 - smoothstep(1. - aax, 1., uv.x);
  float bottom = smoothstep(0., aay, uv.y);
  float top = 1.0 - smoothstep(1. - aay, 1., uv.y);

  return left * right * bottom * top;
}

mat2 rotate2D(float r) {
  return mat2(cos(r), sin(r), -sin(r), cos(r));
}

float getCausticNoise(vec2 uv, float t, float scale) {
  vec2 n = vec2(.1);
  vec2 N = vec2(.1);
  mat2 m = rotate2D(.5);
  for (int j = 0; j < 6; j++) {
    uv *= m;
    n *= m;
    vec2 q = uv * scale + float(j) + n + (.5 + .5 * float(j)) * (mod(float(j), 2.) - 1.) * t;
    n += sin(q);
    N += cos(q) / scale;
    scale *= 1.1;
  }
  return (N.x + N.y + 1.);
}

void main() {
  vec2 imageUV = v_imageUV;
  vec2 patternUV = v_imageUV - .5;
  patternUV = (patternUV * vec2(u_imageAspectRatio, 1.));
  patternUV /= (.01 + .09 * u_size);

  float t = u_time;

  float wavesNoise = snoise((.3 + .1 * sin(t)) * .1 * patternUV + vec2(0., .4 * t));

  float causticNoise = getCausticNoise(patternUV + u_waves * vec2(1., -1.) * wavesNoise, 2. * t, 1.5);

  if (u_layering > 0.) {
    causticNoise += u_layering * getCausticNoise(patternUV + 2. * u_waves * vec2(1., -1.) * wavesNoise, 1.5 * t, 2.);
  }
  causticNoise = causticNoise * causticNoise;

  float edgesDistortion = smoothstep(0., .1, imageUV.x);
  edgesDistortion *= smoothstep(0., .1, imageUV.y);
  edgesDistortion *= (smoothstep(1., 1.1, imageUV.x) + (1.0 - smoothstep(.8, .95, imageUV.x)));
  edgesDistortion *= (1.0 - smoothstep(.9, 1., imageUV.y));
  edgesDistortion = mix(edgesDistortion, 1., u_edges);

  float causticNoiseDistortion = .02 * causticNoise * edgesDistortion;

  float wavesDistortion = .1 * u_waves * wavesNoise;

  imageUV += vec2(wavesDistortion, -wavesDistortion);
  imageUV += (u_caustic * causticNoiseDistortion);

  float frame = getUvFrame(imageUV);

  vec4 image = texture(u_image, imageUV);
  vec4 backColor = u_colorBack;
  backColor.rgb *= backColor.a;

  vec3 color = mix(backColor.rgb, image.rgb, image.a * frame);
  float opacity = backColor.a + image.a * frame;

  causticNoise = max(-.2, causticNoise);

  float hightlight = .025 * u_highlights * causticNoise;
  hightlight *= u_colorHighlight.a;
  color = mix(color, u_colorHighlight.rgb, .05 * u_highlights * causticNoise * u_colorHighlight.a);
  opacity += hightlight;

  color += hightlight * (.5 + .5 * wavesNoise);
  opacity += hightlight * (.5 + .5 * wavesNoise);

  opacity = clamp(opacity, 0., 1.);

  fragColor = vec4(color, opacity);
}
`;function S(e){if(Array.isArray(e))return e.length===4?e:e.length===3?[...e,1]:O;if(typeof e!=`string`)return O;let t,n,r,i=1;if(e.startsWith(`#`))[t,n,r,i]=C(e);else if(e.startsWith(`rgb`)){let a=w(e);if(a===null)return O;[t,n,r,i]=a}else if(e.startsWith(`hsl`)){let a=T(e);if(a===null)return O;[t,n,r,i]=E(a)}else return console.error(`Unsupported color format`,e),O;return[D(t,0,1),D(n,0,1),D(r,0,1),D(i,0,1)]}function C(e){return e=e.replace(/^#/,``),(e.length===3||e.length===4)&&(e=e.split(``).map(e=>e+e).join(``)),e.length===6&&(e+=`ff`),/^[0-9a-f]{8}$/i.test(e)?[parseInt(e.slice(0,2),16)/255,parseInt(e.slice(2,4),16)/255,parseInt(e.slice(4,6),16)/255,parseInt(e.slice(6,8),16)/255]:(console.warn(`Invalid hex color`),O)}function w(e){let t=e.match(/^rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([0-9.]+))?\s*\)$/i);return t?[parseInt(t[1]??`0`)/255,parseInt(t[2]??`0`)/255,parseInt(t[3]??`0`)/255,t[4]===void 0?1:parseFloat(t[4])]:null}function T(e){let t=e.match(/^hsla?\s*\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*(?:,\s*([0-9.]+))?\s*\)$/i);return t?[parseInt(t[1]??`0`),parseInt(t[2]??`0`),parseInt(t[3]??`0`),t[4]===void 0?1:parseFloat(t[4])]:null}function E(e){let[t,n,r,i]=e,a=t/360,o=n/100,s=r/100,c,l,u;if(n===0)c=l=u=s;else{let e=(e,t,n)=>(n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*(2/3-n)*6:e),t=s<.5?s*(1+o):s+o-s*o,n=2*s-t;c=e(n,t,a+1/3),l=e(n,t,a),u=e(n,t,a-1/3)}return[c,l,u,i]}var D=(e,t,n)=>Math.min(Math.max(e,t),n),O=[.5,.5,.5,1],k=e(t(),1);function A(e){let t=k.useRef(void 0),n=k.useCallback(t=>{let n=e.map(e=>{if(e!=null){if(typeof e==`function`){let n=e,r=n(t);return typeof r==`function`?r:()=>{n(null)}}return e.current=t,()=>{e.current=null}}});return()=>{n.forEach(e=>e?.())}},e);return k.useMemo(()=>e.every(e=>e==null)?null:e=>{t.current&&=(t.current(),void 0),e!=null&&(t.current=n(e))},e)}function j(e){if(e.naturalWidth<1024&&e.naturalHeight<1024){if(e.naturalWidth<1||e.naturalHeight<1)return;let t=e.naturalWidth/e.naturalHeight;e.width=Math.round(t>1?1024*t:1024),e.height=Math.round(t>1?1024:1024/t)}}var M=c();async function N(e){let t={},n=[],r=e=>{try{return e.startsWith(`/`)||new URL(e),!0}catch{return!1}},i=e=>{try{return!e.startsWith(`/`)&&new URL(e,window.location.origin).origin!==window.location.origin}catch{return!1}};return Object.entries(e).forEach(([e,a])=>{if(typeof a==`string`){let o=a||`data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==`;if(!r(o)){console.warn(`Uniform "${e}" has invalid URL "${o}". Skipping image loading.`);return}let s=new Promise((n,r)=>{let a=new Image;i(o)&&(a.crossOrigin=`anonymous`),a.onload=()=>{j(a),t[e]=a,n()},a.onerror=()=>{console.error(`Could not set uniforms. Failed to load image at ${o}`),r()},a.src=o});n.push(s)}else if(a instanceof HTMLImageElement){let r=a.decode().then(()=>{j(a),t[e]=a});n.push(r)}else t[e]=a}),await Promise.all(n),t}var P=(0,k.forwardRef)(function({fragmentShader:e,uniforms:t,webGlContextAttributes:n,speed:r=0,frame:i=0,width:a,height:o,minPixelRatio:s,maxPixelCount:c,mipmaps:l,style:u,...d},f){let[m,h]=(0,k.useState)(!1),g=(0,k.useRef)(null),_=(0,k.useRef)(null),v=(0,k.useRef)(n);(0,k.useEffect)(()=>((async()=>{let n=await N(t);g.current&&!_.current&&(_.current=new p(g.current,e,n,v.current,r,i,s,c,l),h(!0))})(),()=>{_.current?.dispose(),_.current=null}),[e]),(0,k.useEffect)(()=>{let e=!1;return(async()=>{let n=await N(t);e||_.current?.setUniforms(n)})(),()=>{e=!0}},[t,m]),(0,k.useEffect)(()=>{_.current?.setSpeed(r)},[r,m]),(0,k.useEffect)(()=>{_.current?.setMaxPixelCount(c)},[c,m]),(0,k.useEffect)(()=>{_.current?.setMinPixelRatio(s)},[s,m]),(0,k.useEffect)(()=>{_.current?.setFrame(i)},[i,m]);let y=A([g,f]);return(0,M.jsx)(`div`,{ref:y,style:a!==void 0||o!==void 0?{width:typeof a==`string`&&isNaN(+a)===!1?+a:a,height:typeof o==`string`&&isNaN(+o)===!1?+o:o,...u}:u,...d})});P.displayName=`ShaderMount`;function F(e,t){if(Object.keys(e).length!==Object.keys(t).length)return!1;for(let n in e)if(n===`colors`){let n=Array.isArray(e.colors),r=Array.isArray(t.colors);if(!n||!r){if(Object.is(e.colors,t.colors)===!1)return!1;continue}if(e.colors?.length!==t.colors?.length||!e.colors?.every((e,n)=>e===t.colors?.[n]))return!1}else if(Object.is(e[n],t[n])===!1)return!1;return!0}var I={name:`Default`,params:{...y,scale:.8,speed:1,frame:0,colorBack:`#909090`,colorHighlight:`#ffffff`,highlights:.07,layering:.5,edges:.8,waves:.3,caustic:.1,size:1}};({...y}),{...y},{...y};var ee=(0,k.memo)(function({speed:e=I.params.speed,frame:t=I.params.frame,colorBack:n=I.params.colorBack,colorHighlight:r=I.params.colorHighlight,image:i=``,highlights:a=I.params.highlights,layering:o=I.params.layering,waves:s=I.params.waves,edges:c=I.params.edges,caustic:l=I.params.caustic,effectScale:u,size:d=u===void 0?I.params.size:10/9/u-1/9,fit:f=I.params.fit,scale:p=I.params.scale,rotation:m=I.params.rotation,originX:h=I.params.originX,originY:g=I.params.originY,offsetX:_=I.params.offsetX,offsetY:v=I.params.offsetY,worldWidth:y=I.params.worldWidth,worldHeight:C=I.params.worldHeight,...w}){let T={u_image:i,u_colorBack:S(n),u_colorHighlight:S(r),u_highlights:a,u_layering:o,u_waves:s,u_edges:c,u_caustic:l,u_size:d,u_fit:b[f],u_rotation:m,u_scale:p,u_offsetX:_,u_offsetY:v,u_originX:h,u_originY:g,u_worldWidth:y,u_worldHeight:C};return(0,M.jsx)(P,{...w,speed:e,frame:t,fragmentShader:x,mipmaps:[`u_image`],uniforms:T})},F),te=n();function ne(){let e=(0,te.c)(2),[t,n]=(0,k.useState)(L),r,i;return e[0]===Symbol.for(`react.memo_cache_sentinel`)?(r=()=>{let e=window.matchMedia(`(prefers-reduced-motion: reduce)`),t=()=>n(e.matches);return e.addEventListener(`change`,t),()=>e.removeEventListener(`change`,t)},i=[],e[0]=r,e[1]=i):(r=e[0],i=e[1]),(0,k.useEffect)(r,i),t}function L(){return typeof window>`u`?!1:window.matchMedia(`(prefers-reduced-motion: reduce)`).matches}var re={login:{title:`A slower kind of stay.`,description:`Cottages tucked into the edge of the New Forest — for long weekends, family gatherings and mornings with nowhere to be.`,footnote:`Cottages · New Forest`},register:{title:`Your next escape starts here.`,description:`Create an account to book directly, keep your details close and return to the quiet whenever you need it.`,footnote:`Cottages · New Forest`},forgot:{title:`We'll get you back in.`,description:`A secure link, a new password and your cottage plans exactly where you left them.`,footnote:`Account support · Hamptworth`},reset:{title:`A fresh start.`,description:`Choose a new password and get back to the quiet — your details and bookings stay right here.`,footnote:`Secure account recovery`},enquiry:{title:`Let's plan your escape.`,description:`A family gathering, a dog-friendly weekend or a date that isn't on the calendar yet — share the shape of your stay and we'll take it from there.`,footnote:`Replies within one working day`}};function R(e){let t=(0,te.c)(69),{mode:n,eyebrow:r,title:i,description:a,children:s,footer:c,wide:l}=e,d=l!==void 0&&l,f=ne(),p=re[n],m=n===`enquiry`,h=d?`grid min-h-dvh bg-background lg:grid-cols-[0.85fr_1.15fr]`:`grid min-h-dvh bg-background lg:grid-cols-2`,g=d?`flex items-center justify-between gap-4 px-5 pt-3 sm:px-8 sm:pt-4 lg:px-10 lg:pt-5 xl:px-12`:`flex items-center justify-between gap-4 px-5 pt-5 sm:px-8 lg:px-12 lg:pt-8 xl:px-16`,_=d?`h-9 w-auto object-contain mix-blend-multiply sm:h-10 lg:h-11`:`h-12 w-auto object-contain mix-blend-multiply lg:h-14`,v;t[0]===_?v=t[1]:(v=(0,M.jsx)(o,{to:`/`,"aria-label":`Hamptworth Stays — home`,className:`inline-flex shrink-0 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring`,children:(0,M.jsx)(`img`,{src:`/navlogo.webp`,alt:`Hamptworth Stays`,className:_})}),t[0]=_,t[1]=v);let y;t[2]===Symbol.for(`react.memo_cache_sentinel`)?(y=(0,M.jsxs)(o,{to:`/`,className:`group inline-flex items-center gap-2 text-[12px] text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring`,children:[(0,M.jsx)(u,{className:`size-3.5 transition-transform duration-300 group-hover:-translate-x-0.5`,"aria-hidden":!0}),`Back to cottages`]}),t[2]=y):y=t[2];let b;t[3]!==g||t[4]!==v?(b=(0,M.jsxs)(`header`,{className:g,children:[v,y]}),t[3]=g,t[4]=v,t[5]=b):b=t[5];let x=d?`flex flex-1 items-center justify-center px-5 py-4 sm:px-8 sm:py-5 lg:px-10 lg:py-6 xl:px-12`:`flex flex-1 items-center justify-center px-5 py-7 sm:px-8 lg:px-12 lg:py-10 xl:px-16`,S=d?`w-full max-w-[680px]`:`w-full max-w-[420px]`,C;t[6]===r?C=t[7]:(C=(0,M.jsx)(`p`,{className:`text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground`,children:r}),t[6]=r,t[7]=C);let w=d?`mt-2 font-display text-3xl font-normal leading-[1.04] tracking-tight text-foreground sm:text-4xl`:`mt-3 font-display text-4xl font-normal leading-[1.02] tracking-tight text-foreground sm:text-5xl`,T;t[8]!==w||t[9]!==i?(T=(0,M.jsx)(`h1`,{className:w,children:i}),t[8]=w,t[9]=i,t[10]=T):T=t[10];let E;t[11]===a?E=t[12]:(E=(0,M.jsx)(`p`,{className:`mt-3 text-sm leading-relaxed text-muted-foreground`,children:a}),t[11]=a,t[12]=E);let D=d?`mt-5`:`mt-6`,O;t[13]!==s||t[14]!==D?(O=(0,M.jsx)(`div`,{className:D,children:s}),t[13]=s,t[14]=D,t[15]=O):O=t[15];let k=d?`mt-4 text-sm text-muted-foreground`:`mt-6 text-sm text-muted-foreground`,A;t[16]!==c||t[17]!==k?(A=(0,M.jsx)(`div`,{className:k,children:c}),t[16]=c,t[17]=k,t[18]=A):A=t[18];let j;t[19]!==C||t[20]!==T||t[21]!==E||t[22]!==O||t[23]!==A||t[24]!==S?(j=(0,M.jsxs)(`div`,{className:S,children:[C,T,E,O,A]}),t[19]=C,t[20]=T,t[21]=E,t[22]=O,t[23]=A,t[24]=S,t[25]=j):j=t[25];let N;t[26]!==j||t[27]!==x?(N=(0,M.jsx)(`main`,{className:x,children:j}),t[26]=j,t[27]=x,t[28]=N):N=t[28];let P=d?`hidden flex-wrap items-center justify-between gap-3 px-5 pb-4 text-[10px] text-muted-foreground sm:flex sm:px-8 lg:px-10 xl:px-12`:`hidden flex-wrap items-center justify-between gap-3 px-5 pb-5 text-[10px] text-muted-foreground sm:flex sm:px-8 lg:px-12 xl:px-16`,F,I;t[29]===Symbol.for(`react.memo_cache_sentinel`)?(F=(0,M.jsx)(`span`,{children:`© 2026 Hamptworth Stays`}),I=(0,M.jsx)(`span`,{children:`Home Farm · Hamptworth`}),t[29]=F,t[30]=I):(F=t[29],I=t[30]);let L;t[31]===P?L=t[32]:(L=(0,M.jsxs)(`footer`,{className:P,children:[F,I]}),t[31]=P,t[32]=L);let R;t[33]!==N||t[34]!==L||t[35]!==b?(R=(0,M.jsxs)(`section`,{className:`order-2 flex min-h-dvh flex-col`,children:[b,N,L]}),t[33]=N,t[34]=L,t[35]=b,t[36]=R):R=t[36];let z=m?`#141a10`:`#0b1a12`,B=f?0:.3,V;t[37]!==z||t[38]!==B?(V=(0,M.jsx)(ee,{"aria-hidden":`true`,className:`absolute inset-0 h-full w-full`,image:`/Bright_Orange_flower.png`,colorBack:z,colorHighlight:`#f7f3e6`,highlights:.12,layering:.5,edges:.6,waves:.25,caustic:.12,size:1,speed:B,scale:1.1,fit:`cover`,maxPixelCount:22e5}),t[37]=z,t[38]=B,t[39]=V):V=t[39];let H,U,W,G;t[40]===Symbol.for(`react.memo_cache_sentinel`)?(H=(0,M.jsx)(`div`,{"aria-hidden":`true`,className:`absolute inset-0 bg-[linear-gradient(180deg,rgba(7,16,11,0.78)_0%,rgba(7,16,11,0.34)_16%,rgba(7,16,11,0.04)_36%,rgba(7,16,11,0.16)_56%,rgba(7,16,11,0.82)_82%,rgba(7,16,11,0.96)_100%)]`}),U=(0,M.jsx)(`div`,{"aria-hidden":`true`,className:`absolute inset-0 bg-[radial-gradient(ellipse_at_22%_96%,rgba(201,162,75,0.26),transparent_58%)]`}),W=(0,M.jsx)(`div`,{"aria-hidden":`true`,className:`absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_38%,rgba(5,12,8,0.55)_100%)]`}),G=(0,M.jsx)(`div`,{"aria-hidden":`true`,className:`absolute inset-y-0 right-0 w-px bg-[linear-gradient(180deg,transparent,rgba(201,162,75,0.35),transparent)]`}),t[40]=H,t[41]=U,t[42]=W,t[43]=G):(H=t[40],U=t[41],W=t[42],G=t[43]);let ie=d?`relative z-10 flex justify-end p-8 xl:p-10`:`relative z-10 flex justify-end p-9 xl:p-12`,K;t[44]===Symbol.for(`react.memo_cache_sentinel`)?(K=(0,M.jsx)(`img`,{src:`/navlogo.webp`,alt:`Hamptworth Stays`,className:`h-12 w-auto brightness-0 invert opacity-90 drop-shadow-[0_2px_18px_rgba(0,0,0,0.35)]`}),t[44]=K):K=t[44];let q;t[45]===ie?q=t[46]:(q=(0,M.jsx)(o,{to:`/`,className:ie,children:K}),t[45]=ie,t[46]=q);let ae=d?`relative z-10 p-8 xl:p-10`:`relative z-10 p-9 xl:p-12`,J;t[47]===Symbol.for(`react.memo_cache_sentinel`)?(J=(0,M.jsxs)(`p`,{className:`flex items-center gap-3 text-[10px] uppercase tracking-[0.28em] text-[#f7f3e6]/65`,children:[(0,M.jsx)(`span`,{"aria-hidden":!0,className:`h-px w-6 bg-[#c9a24b]/80`}),`Home Farm · Hamptworth`]}),t[47]=J):J=t[47];let oe=d?`mt-4 max-w-md text-balance font-display text-4xl font-normal leading-[0.98] tracking-tight text-[#f7f3e6] xl:text-5xl`:`mt-4 max-w-md text-balance font-display text-5xl font-normal leading-[0.96] tracking-tight text-[#f7f3e6] xl:text-6xl`,Y;t[48]!==p.title||t[49]!==oe?(Y=(0,M.jsx)(`h2`,{className:oe,children:p.title}),t[48]=p.title,t[49]=oe,t[50]=Y):Y=t[50];let X;t[51]===p.description?X=t[52]:(X=(0,M.jsx)(`p`,{className:`mt-5 max-w-sm text-pretty text-sm leading-relaxed text-[#f7f3e6]/75`,children:p.description}),t[51]=p.description,t[52]=X);let se;t[53]===Symbol.for(`react.memo_cache_sentinel`)?(se=(0,M.jsx)(`span`,{"aria-hidden":!0,className:`h-px w-8 bg-[#c9a24b]`}),t[53]=se):se=t[53];let Z;t[54]===p.footnote?Z=t[55]:(Z=(0,M.jsxs)(`div`,{className:`mt-8 flex items-center gap-3 text-[10px] uppercase tracking-[0.2em] text-[#f7f3e6]/55`,children:[se,p.footnote]}),t[54]=p.footnote,t[55]=Z);let Q;t[56]!==ae||t[57]!==Y||t[58]!==X||t[59]!==Z?(Q=(0,M.jsxs)(`div`,{className:ae,children:[J,Y,X,Z]}),t[56]=ae,t[57]=Y,t[58]=X,t[59]=Z,t[60]=Q):Q=t[60];let $;t[61]!==V||t[62]!==q||t[63]!==Q?($=(0,M.jsxs)(`aside`,{className:`relative order-1 hidden overflow-hidden bg-[#0b1a12] lg:sticky lg:top-0 lg:flex lg:h-dvh lg:self-start lg:flex-col lg:justify-between`,children:[V,H,U,W,G,q,Q]}),t[61]=V,t[62]=q,t[63]=Q,t[64]=$):$=t[64];let ce;return t[65]!==h||t[66]!==R||t[67]!==$?(ce=(0,M.jsxs)(`div`,{className:h,children:[R,$]}),t[65]=h,t[66]=R,t[67]=$,t[68]=ce):ce=t[68],ce}function z(e){let t=(0,te.c)(5),n=e===void 0?`/`:e,o=a(),s=i(),c=r(B),l=s.state?.from,u=l&&l!==`/login`&&l!==`/register`?l:n,d,f;t[0]!==u||t[1]!==o||t[2]!==c?(d=()=>{c&&o(u,{replace:!0})},f=[c,u,o],t[0]=u,t[1]=o,t[2]=c,t[3]=d,t[4]=f):(d=t[3],f=t[4]),(0,k.useEffect)(d,f)}function B(e){return e.user}export{R as n,z as t};