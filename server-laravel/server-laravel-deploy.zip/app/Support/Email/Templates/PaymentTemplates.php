<?php

namespace App\Support\Email\Templates;

use App\Support\Email\EmailShared;

class PaymentTemplates
{
    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function paymentFailed(array $ctx): array
    {
        $html = EmailShared::layout(
            'Payment did not go through',
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Your bank declined the charge for booking '.EmailShared::refPill((string) $ctx['bookingReference']).'. No money was captured.')
                .EmailShared::infoCard(
                    EmailShared::p('You can <strong>retry</strong> while the hold is valid (until '.EmailShared::escapeHtml((string) $ctx['holdExpiresAt']).').')
                )
                .EmailShared::emailButton((string) $ctx['manageUrl'], 'Retry payment →'),
            'Retry from your bookings page: '.EmailShared::escapeHtml((string) $ctx['manageUrl']).' — or contact '.EmailShared::escapeHtml((string) $ctx['supportEmail']).'.',
            ['preheader' => "Your payment for {$ctx['bookingReference']} did not go through"]
        );

        return EmailShared::rendered(
            'Payment failed — '.$ctx['bookingReference'],
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Your bank declined the charge for booking {$ctx['bookingReference']}. No money was captured.",
                '',
                "You can retry while the hold is valid (until {$ctx['holdExpiresAt']}).",
                '',
                "Retry from your bookings page: {$ctx['manageUrl']}",
                "Or contact {$ctx['supportEmail']}.",
                '',
                'Warm wishes,',
                'The Hamptworth Stays Team',
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function refundUpdated(array $ctx): array
    {
        $html = EmailShared::layout(
            'Refund update',
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Refund of <strong>'.EmailShared::money((int) $ctx['refundAmount'], (string) $ctx['currency']).'</strong> for booking '.EmailShared::refPill((string) $ctx['bookingReference']).' is now <strong>'.EmailShared::escapeHtml((string) $ctx['refundStatus']).'</strong>.'),
            'Questions? Contact '.EmailShared::escapeHtml((string) $ctx['supportEmail']).'.',
            ['preheader' => "Your refund for {$ctx['bookingReference']} is {$ctx['refundStatus']}"]
        );

        return EmailShared::rendered(
            'Refund update — '.$ctx['bookingReference'],
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Refund of {$ctx['currency']} ".number_format(((int) $ctx['refundAmount']) / 100, 2, '.', '')." for booking {$ctx['bookingReference']} is now {$ctx['refundStatus']}.",
                '',
                "Questions? Contact {$ctx['supportEmail']}.",
                '',
                'Warm wishes,',
                'The Hamptworth Stays Team',
            ])
        );
    }
}
