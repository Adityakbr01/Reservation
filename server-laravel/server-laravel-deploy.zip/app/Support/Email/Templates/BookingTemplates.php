<?php

namespace App\Support\Email\Templates;

use App\Support\Email\EmailShared;

class BookingTemplates
{
    /**
     * @param  array<string, mixed>  $ctx
     * @return array{brandName: string, brandSiteUrl: string, bookingSiteUrl: string}
     */
    private static function linksFor(array $ctx): array
    {
        return EmailShared::brandLinks([
            'brandName' => trim((string) ($ctx['brandName'] ?? '')) ?: (string) ($ctx['propertyName'] ?? ''),
            'brandSiteUrl' => $ctx['brandSiteUrl'] ?? null,
            'bookingSiteUrl' => $ctx['bookingSiteUrl'] ?? null,
        ]);
    }

    private static function brandNameFor(array $ctx): string
    {
        return self::linksFor($ctx)['brandName'];
    }

    private static function totalText(array $ctx): string
    {
        return ((string) $ctx['currency']).' '.number_format(((int) $ctx['total']) / 100, 2, '.', '');
    }

    private static function arrivalCard(array $ctx): string
    {
        return EmailShared::sectionTitle('Your arrival')
            .EmailShared::infoCard(
                EmailShared::infoRow('Check-in', EmailShared::escapeHtml(EmailShared::checkInLabel($ctx['checkInTime'] ?? null)))
                .EmailShared::infoRow('Check-out', EmailShared::escapeHtml(EmailShared::checkOutLabel($ctx['checkOutTime'] ?? null)))
            );
    }

    private static function findingUsCard(array $ctx): string
    {
        $address = trim((string) ($ctx['propertyAddress'] ?? ''));
        $mapsUrl = trim((string) ($ctx['mapsUrl'] ?? '')) ?: EmailShared::mapsDirectionsUrl($address);
        if ($address === '' && $mapsUrl === null) {
            return '';
        }
        $addressLine = $address !== ''
            ? '<p style="margin: 0 0 6px 0; font-family: Arial,Helvetica,sans-serif; font-size: 15px; color: '.EmailShared::THEME['ink'].';">'.EmailShared::escapeHtml($address).'</p>'
            : '';
        $mapsLine = $mapsUrl !== null
            ? '<a href="'.EmailShared::escapeHtml($mapsUrl).'" style="font-family: Arial,Helvetica,sans-serif; font-size: 14px; font-weight: 600; color: '.EmailShared::THEME['forest'].'; text-decoration: underline; text-underline-offset: 3px;">Get directions on Google Maps →</a>'
            : '';

        return EmailShared::sectionTitle('Finding us').EmailShared::infoCard($addressLine.$mapsLine);
    }

    private static function stayCard(array $ctx): string
    {
        $nights = (int) $ctx['nights'];
        $detailLine = EmailShared::escapeHtml((string) $ctx['checkIn']).' &nbsp;→&nbsp; '.EmailShared::escapeHtml((string) $ctx['checkOut'])
            .'<br />'.$nights.' night'.($nights === 1 ? '' : 's').' · '.EmailShared::escapeHtml((string) $ctx['guests']);

        return EmailShared::heroCard((string) $ctx['bookingReference'], (string) $ctx['roomSummary'], $detailLine);
    }

    private static function websitesBlock(array $ctx): string
    {
        $links = self::linksFor($ctx);

        return EmailShared::sectionTitle('Our websites').EmailShared::textLinks([
            ['url' => $links['brandSiteUrl'], 'label' => "Explore {$links['brandName']} →"],
            ['url' => $links['bookingSiteUrl'], 'label' => 'Visit our booking website →'],
        ]);
    }

    private static function footerLine(array $ctx): string
    {
        return 'Questions? Reply to '.EmailShared::escapeHtml((string) $ctx['supportEmail'])
            .'. Manage: '.EmailShared::escapeHtml((string) $ctx['manageUrl']);
    }

    private static function websitesText(array $links): string
    {
        return "Explore {$links['brandName']}: {$links['brandSiteUrl']}\nPlan your stay: {$links['bookingSiteUrl']}";
    }

    private static function summaryTable(array $ctx): string
    {
        $row = static function (string $label, string $value): string {
            return '<tr><td style="font-family: Arial,Helvetica,sans-serif; font-size: 13.5px; color: '.EmailShared::THEME['muted'].'; padding: 9px 0; border-bottom: 1px solid '.EmailShared::THEME['ivoryDeep'].';">'.$label.'</td><td align="right" style="font-family: Arial,Helvetica,sans-serif; font-size: 13.5px; font-weight: 600; color: '.EmailShared::THEME['body'].'; padding: 9px 0; border-bottom: 1px solid '.EmailShared::THEME['ivoryDeep'].';">'.$value.'</td></tr>';
        };
        $currency = (string) $ctx['currency'];
        $rows = $row('Booking reference', '<strong>'.EmailShared::escapeHtml((string) $ctx['bookingReference']).'</strong>')
            .$row('Cottage', EmailShared::escapeHtml((string) $ctx['roomSummary']))
            .$row('Check-in', EmailShared::escapeHtml((string) $ctx['checkIn']))
            .$row('Check-out', EmailShared::escapeHtml((string) $ctx['checkOut']))
            .$row('Nights / guests', ((int) $ctx['nights']).' / '.EmailShared::escapeHtml((string) $ctx['guests']))
            .$row('Subtotal', EmailShared::money((int) $ctx['subtotal'], $currency))
            .$row('Discount', EmailShared::money((int) $ctx['discount'], $currency))
            .$row('Taxes &amp; fees', EmailShared::money((int) $ctx['taxes'] + (int) $ctx['fees'], $currency));

        return EmailShared::sectionTitle('Booking summary')
            .'<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin: 10px 0; background-color: #ffffff; border: 1px solid '.EmailShared::THEME['border'].'; border-radius: 4px;"><tr><td style="padding: 10px 22px 6px 22px;"><table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">'
            .$rows
            .'</table></td></tr><tr><td style="background-color: '.EmailShared::THEME['ivory'].'; border-top: 2px solid '.EmailShared::THEME['gold'].'; border-radius: 0 0 3px 3px; padding: 14px 22px;"><table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="font-family: Arial,Helvetica,sans-serif; font-size: 12px; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: '.EmailShared::THEME['bronze'].';">Total</td><td align="right" style="font-family: Georgia,\'Times New Roman\',serif; font-size: 24px; font-weight: 700; color: '.EmailShared::THEME['forest'].';">'.EmailShared::money((int) $ctx['total'], $currency).'</td></tr>'
            .'<tr><td colspan="2" style="font-family: Arial,Helvetica,sans-serif; font-size: 12.5px; color: '.EmailShared::THEME['muted'].'; padding-top: 4px;">Total paid: '.EmailShared::money((int) $ctx['totalPaid'], $currency).' ('.EmailShared::escapeHtml((string) $ctx['paymentStatus']).')</td></tr>'
            .'</table></td></tr></table>';
    }

    private static function summaryText(array $ctx): string
    {
        return implode("\n", [
            'Booking reference: '.$ctx['bookingReference'],
            'Cottage: '.$ctx['roomSummary'],
            'Check-in: '.$ctx['checkIn'],
            'Check-out: '.$ctx['checkOut'],
            'Nights / guests: '.$ctx['nights'].' / '.$ctx['guests'],
            'Total: '.self::totalText($ctx),
            'Total paid: '.$ctx['currency'].' '.number_format(((int) $ctx['totalPaid']) / 100, 2, '.', '').' ('.$ctx['paymentStatus'].')',
        ]);
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function bookingReceived(array $ctx): array
    {
        $brand = self::brandNameFor($ctx);
        $links = self::linksFor($ctx);
        $html = EmailShared::layout(
            'Booking received',
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Thank you for choosing <strong>'.EmailShared::escapeHtml((string) $ctx['roomSummary']).'</strong> with <strong>'.EmailShared::escapeHtml($brand).'</strong>. We are holding your rooms while payment completes — please finish payment before the hold expires, or the booking is released automatically.')
                .self::stayCard($ctx)
                .self::summaryTable($ctx)
                .EmailShared::emailButton((string) $ctx['manageUrl'], 'Complete payment →'),
            self::footerLine($ctx),
            ['preheader' => "We're holding {$ctx['roomSummary']} while your payment completes"]
        );

        return EmailShared::rendered(
            'Booking received — '.$ctx['bookingReference'],
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Thank you for choosing {$ctx['roomSummary']} with {$brand}. We are holding your rooms while payment completes — please finish payment before the hold expires, or the booking is released automatically.",
                '',
                self::summaryText($ctx),
                '',
                "Complete payment: {$ctx['manageUrl']}",
                '',
                self::websitesText($links),
                '',
                'Warm wishes,',
                "The {$brand} Team",
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function bookingConfirmed(array $ctx): array
    {
        $links = self::linksFor($ctx);
        $brand = $links['brandName'];
        $address = trim((string) ($ctx['propertyAddress'] ?? ''));
        $mapsUrl = trim((string) ($ctx['mapsUrl'] ?? '')) ?: EmailShared::mapsDirectionsUrl($address);
        $receiptUrl = (string) ($ctx['downloadReceiptUrl'] ?? $ctx['receiptUrl'] ?? $ctx['manageUrl']);

        $html = EmailShared::layout(
            'Booking confirmed',
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Thank you for booking <strong>'.EmailShared::escapeHtml((string) $ctx['roomSummary']).'</strong> with <strong>'.EmailShared::escapeHtml($brand).'</strong>. We’re delighted you’ll be joining us for a countryside escape.')
                .EmailShared::p('Your payment has been received and your booking is confirmed. You can view or download your official receipt at any time using the button below.')
                .self::stayCard($ctx)
                .self::summaryTable($ctx)
                .EmailShared::emailButton($receiptUrl, 'Download Receipt (PDF) →')
                .self::arrivalCard($ctx)
                .self::findingUsCard($ctx)
                .EmailShared::p('Please keep your booking reference handy. For any questions before your stay, get in touch through our booking website below.')
                .self::websitesBlock($ctx)
                .EmailShared::p('<span style="font-size: 13px; color: '.EmailShared::THEME['muted'].';">Cancellation policy: '.EmailShared::escapeHtml((string) $ctx['cancellationPolicy']).'</span>'),
            self::footerLine($ctx),
            ['preheader' => "Your stay at {$ctx['roomSummary']} is confirmed — Official Receipt enclosed"]
        );

        return EmailShared::rendered(
            'Booking confirmed — '.$ctx['bookingReference'],
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Thank you for booking {$ctx['roomSummary']} with {$brand}. We're delighted you'll be joining us for a countryside escape.",
                '',
                'Your payment has been received and your booking is confirmed.',
                '',
                self::summaryText($ctx),
                '',
                "Download Receipt (PDF): {$receiptUrl}",
                '',
                'Your arrival',
                'Check-in: '.EmailShared::checkInLabel($ctx['checkInTime'] ?? null),
                'Check-out: '.EmailShared::checkOutLabel($ctx['checkOutTime'] ?? null),
                '',
                $address !== '' ? "Finding us\n{$address}\n".($mapsUrl ?? '') : '',
                '',
                'Please keep your booking reference handy. For any questions before your stay, get in touch through our booking website below.',
                '',
                self::websitesText($links),
                '',
                "Manage your booking: {$receiptUrl}",
                '',
                "Cancellation policy: {$ctx['cancellationPolicy']}",
                '',
                'Warm wishes,',
                "The {$brand} Team",
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function bookingCancelled(array $ctx): array
    {
        $brand = self::brandNameFor($ctx);
        $refundAmount = (int) ($ctx['refundAmount'] ?? 0);
        $refundHtml = $refundAmount > 0
            ? EmailShared::p('Refund of <strong>'.EmailShared::money($refundAmount, (string) $ctx['currency']).'</strong> is '.EmailShared::escapeHtml((string) $ctx['refundStatus']).'. It reaches the original payment method in 5–10 business days.')
            : EmailShared::p('No refund was due for this cancellation.');
        $refundText = $refundAmount > 0
            ? 'Refund of '.$ctx['currency'].' '.number_format($refundAmount / 100, 2, '.', '').' is '.$ctx['refundStatus'].'. It reaches the original payment method in 5–10 business days.'
            : 'No refund was due for this cancellation.';
        $html = EmailShared::layout(
            'Booking cancelled',
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Booking '.EmailShared::refPill((string) $ctx['bookingReference']).'<br /><span style="font-size: 14px;">'.EmailShared::escapeHtml((string) $ctx['checkIn']).' → '.EmailShared::escapeHtml((string) $ctx['checkOut']).' · cancelled on '.EmailShared::escapeHtml((string) $ctx['cancelledAt']).'.</span>')
                .$refundHtml,
            'Questions? Contact '.EmailShared::escapeHtml((string) $ctx['supportEmail']).'.',
            ['preheader' => "Your booking {$ctx['bookingReference']} was cancelled"]
        );

        return EmailShared::rendered(
            'Booking cancelled — '.$ctx['bookingReference'],
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Booking {$ctx['bookingReference']} ({$ctx['checkIn']} → {$ctx['checkOut']}) was cancelled on {$ctx['cancelledAt']}.",
                $refundText,
                '',
                "Questions? Contact {$ctx['supportEmail']}.",
                '',
                'Warm wishes,',
                "The {$brand} Team",
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function checkedIn(array $ctx): array
    {
        $links = self::linksFor($ctx);
        $html = EmailShared::layout(
            'Welcome to '.EmailShared::escapeHtml((string) $ctx['roomSummary']),
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Welcome to <strong>'.EmailShared::escapeHtml((string) $ctx['roomSummary']).'</strong>. We’re delighted to have you here at <strong>'.EmailShared::escapeHtml($links['brandName']).'</strong>.')
                .EmailShared::p('Unpack, settle in and make the most of your countryside days. Whether you’re heading out to explore or enjoying a quiet morning, we hope you feel at home.')
                .EmailShared::infoCard(
                    '<p style="margin: 0 0 8px 0;">'.EmailShared::refPill((string) $ctx['bookingReference']).'</p>'
                    .'<p style="margin: 6px 0 0 0; font-family: Arial,Helvetica,sans-serif; font-size: 14px; line-height: 1.7; color: '.EmailShared::THEME['body'].';">If you need anything during your stay, please get in touch through our booking website below.</p>'
                )
                .EmailShared::p('<strong>A little reminder:</strong> Check-out is before <strong>'.EmailShared::escapeHtml(EmailShared::checkOutLabel($ctx['checkOutTime'] ?? null)).'</strong> on your departure day ('.EmailShared::escapeHtml((string) $ctx['checkOut']).').')
                .EmailShared::textLinks([
                    ['url' => $links['brandSiteUrl'], 'label' => "Explore {$links['brandName']} →"],
                    ['url' => $links['bookingSiteUrl'], 'label' => 'Booking website &amp; enquiries →'],
                ]),
            'Questions? Contact '.EmailShared::escapeHtml((string) $ctx['supportEmail']).'.',
            ['preheader' => "Welcome to {$ctx['roomSummary']}"]
        );

        return EmailShared::rendered(
            EmailShared::safeSubjectText('Welcome to '.$ctx['roomSummary'].' — '.$ctx['bookingReference']),
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Welcome to {$ctx['roomSummary']}. We're delighted to have you here at {$links['brandName']}.",
                '',
                "Unpack, settle in and make the most of your countryside days. Whether you're heading out to explore or enjoying a quiet morning, we hope you feel at home.",
                '',
                "Booking reference: {$ctx['bookingReference']}. If you need anything during your stay, please get in touch through our booking website below.",
                '',
                'A little reminder: Check-out is before '.EmailShared::checkOutLabel($ctx['checkOutTime'] ?? null)." on your departure day ({$ctx['checkOut']}).",
                '',
                self::websitesText($links),
                '',
                'Warm wishes,',
                "The {$links['brandName']} Team",
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function checkedOut(array $ctx): array
    {
        $links = self::linksFor($ctx);
        $html = EmailShared::layout(
            'Thank you for staying at '.EmailShared::escapeHtml((string) $ctx['roomSummary']),
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('Thank you for choosing <strong>'.EmailShared::escapeHtml((string) $ctx['roomSummary']).'</strong> by <strong>'.EmailShared::escapeHtml($links['brandName']).'</strong>.')
                .EmailShared::p('We hope you enjoyed your countryside escape and created some wonderful memories during your stay.')
                .EmailShared::infoCard(
                    '<p style="margin: 0 0 8px 0;">'.EmailShared::refPill((string) $ctx['bookingReference']).'</p>'
                    .'<p style="margin: 6px 0 0 0; font-family: Georgia,\'Times New Roman\',serif; font-size: 18px; font-weight: 700; color: '.EmailShared::THEME['forest'].';">'.EmailShared::money((int) $ctx['total'], (string) $ctx['currency']).' <span style="font-family: Arial,Helvetica,sans-serif; font-size: 12.5px; font-weight: 400; color: '.EmailShared::THEME['muted'].';">('.EmailShared::escapeHtml((string) $ctx['paymentStatus']).')</span></p>'
                    .'<p style="margin: 8px 0 0 0; font-family: Arial,Helvetica,sans-serif; font-size: 14px; line-height: 1.7; color: '.EmailShared::THEME['body'].';">We’d love to hear about your experience. If you have any feedback, please get in touch through our booking website.</p>'
                )
                .EmailShared::p('We wish you a safe onward journey and would be delighted to welcome you back.')
                .EmailShared::textLinks([
                    ['url' => $links['brandSiteUrl'], 'label' => "Explore {$links['brandName']} →"],
                    ['url' => $links['bookingSiteUrl'], 'label' => 'Plan Your Next Stay →'],
                ]),
            'Questions about charges? Contact '.EmailShared::escapeHtml((string) $ctx['supportEmail']).'.',
            ['preheader' => "Thank you for staying at {$ctx['roomSummary']}"]
        );

        return EmailShared::rendered(
            EmailShared::safeSubjectText('Thank You for Staying at '.$ctx['roomSummary']),
            $html,
            implode("\n", [
                "Hello {$ctx['guestName']},",
                '',
                "Thank you for choosing {$ctx['roomSummary']} by {$links['brandName']}.",
                '',
                'We hope you enjoyed your countryside escape and created some wonderful memories during your stay.',
                '',
                "Booking reference: {$ctx['bookingReference']}. Total: ".self::totalText($ctx)." ({$ctx['paymentStatus']}).",
                '',
                "We'd love to hear about your experience. If you have any feedback, please get in touch through our booking website.",
                '',
                'We wish you a safe onward journey and would be delighted to welcome you back.',
                '',
                "Explore {$links['brandName']}: {$links['brandSiteUrl']}",
                "Plan Your Next Stay: {$links['bookingSiteUrl']}",
                '',
                'Warm wishes,',
                "The {$links['brandName']} Team",
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $ctx
     * @return array{subject: string, html: string, text: string}
     */
    public static function checkinReminder(array $ctx): array
    {
        $links = self::linksFor($ctx);
        $brand = $links['brandName'];
        $address = trim((string) ($ctx['propertyAddress'] ?? ''));
        $mapsUrl = trim((string) ($ctx['mapsUrl'] ?? '')) ?: EmailShared::mapsDirectionsUrl($address);
        $html = EmailShared::layout(
            'See you tomorrow',
            EmailShared::escapeHtml((string) $ctx['guestName']),
            EmailShared::p('A gentle reminder — check-in for booking '.EmailShared::refPill((string) $ctx['bookingReference']).' at '.EmailShared::escapeHtml($brand).' is <strong>'.EmailShared::escapeHtml((string) $ctx['checkIn']).'</strong>. Rooms: '.EmailShared::escapeHtml((string) $ctx['roomSummary']).'.')
                .self::arrivalCard($ctx)
                .self::findingUsCard($ctx)
                .self::stayCard($ctx)
                .EmailShared::emailButton((string) $ctx['manageUrl'], 'Manage your booking →'),
            'Manage your booking: '.EmailShared::escapeHtml((string) $ctx['manageUrl']).' — or contact '.EmailShared::escapeHtml((string) $ctx['supportEmail']).'.',
            ['preheader' => "Check-in tomorrow at {$ctx['roomSummary']}"]
        );

        $textLines = [
            "Hello {$ctx['guestName']},",
            '',
            "A gentle reminder — check-in for booking {$ctx['bookingReference']} at {$brand} is {$ctx['checkIn']}. Rooms: {$ctx['roomSummary']}.",
            '',
            'Your arrival',
            'Check-in: '.EmailShared::checkInLabel($ctx['checkInTime'] ?? null),
            'Check-out: '.EmailShared::checkOutLabel($ctx['checkOutTime'] ?? null),
        ];
        if ($address !== '') {
            $textLines[] = '';
            $textLines[] = 'Finding us';
            $textLines[] = $address;
            $textLines[] = $mapsUrl ?? '';
        }
        $textLines = array_merge($textLines, [
            '',
            self::summaryText($ctx),
            '',
            "Manage your booking: {$ctx['manageUrl']}",
            '',
            'Warm wishes,',
            "The {$brand} Team",
        ]);

        return EmailShared::rendered('Check-in tomorrow — '.$ctx['bookingReference'], $html, implode("\n", $textLines));
    }
}
