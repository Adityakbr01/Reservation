<?php

namespace App\Support\Email\Templates;

use App\Support\Email\EmailShared;

class AuthTemplates
{
    /**
     * @param  array<string, mixed>  $options
     * @return array{brandName: string, brandSiteUrl: string, bookingSiteUrl: string, loginUrl: string}
     */
    private static function resolveBrand(array $options = []): array
    {
        $links = EmailShared::brandLinks([
            'brandName' => $options['brandName'] ?? null,
            'brandSiteUrl' => $options['brandSiteUrl'] ?? null,
            'bookingSiteUrl' => $options['bookingSiteUrl'] ?? null,
        ]);
        $links['loginUrl'] = trim((string) ($options['loginUrl'] ?? ''))
            ?: rtrim($links['bookingSiteUrl'], '/').'/login';

        return $links;
    }

    /**
     * @param  array<string, mixed>  $options
     * @return array{subject: string, html: string, text: string}
     */
    public static function passwordReset(string $name, string $resetUrl, array $options = []): array
    {
        $brand = self::resolveBrand($options);
        $html = EmailShared::layout(
            'Reset your password',
            EmailShared::escapeHtml($name),
            EmailShared::p('We’ve received a request to reset the password for your <strong>'.EmailShared::escapeHtml($brand['brandName']).'</strong> account.')
                .EmailShared::p('Click the button below to choose a new password.')
                .EmailShared::emailButton($resetUrl, 'Reset Your Password')
                .EmailShared::infoCard(EmailShared::p('<span style="font-size: 13.5px;">If you didn’t request a password reset, you can safely ignore this email. Your password will remain unchanged.<br />For your security, the reset link will expire after 1 hour.</span>'))
                .EmailShared::textLinks([
                    ['url' => $brand['brandSiteUrl'], 'label' => "Explore {$brand['brandName']} →"],
                    ['url' => $brand['bookingSiteUrl'], 'label' => 'Visit our booking website →'],
                ]),
            'If you did not request this, you can ignore this email.',
            ['preheader' => 'Choose a new password for your account']
        );

        return EmailShared::rendered(
            EmailShared::safeSubjectText("Reset Your {$brand['brandName']} Password"),
            $html,
            implode("\n", [
                "Hello {$name},",
                '',
                "We've received a request to reset the password for your {$brand['brandName']} account.",
                '',
                'Click the link below to choose a new password:',
                $resetUrl,
                '',
                "If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.",
                '',
                'For your security, the reset link will expire after 1 hour.',
                '',
                'Warm wishes,',
                "The {$brand['brandName']} Team",
                '',
                $brand['brandSiteUrl'],
            ])
        );
    }

    /**
     * @param  array<string, mixed>  $options
     * @return array{subject: string, html: string, text: string}
     */
    public static function passwordChanged(string $name, array $options = []): array
    {
        $brand = self::resolveBrand($options);
        $html = EmailShared::layout(
            'Password reset successful',
            EmailShared::escapeHtml($name),
            EmailShared::p('Your <strong>'.EmailShared::escapeHtml($brand['brandName']).'</strong> account password has been successfully reset.')
                .EmailShared::p('You can now sign in using your new password.')
                .EmailShared::emailButton($brand['loginUrl'], 'Sign In to Your Account')
                .EmailShared::infoCard(EmailShared::p('<span style="font-size: 13.5px;">If you didn’t make this change, please contact our team immediately through our booking website.</span>'))
                .EmailShared::textLinks([
                    ['url' => $brand['brandSiteUrl'], 'label' => "Explore {$brand['brandName']} →"],
                    ['url' => $brand['bookingSiteUrl'], 'label' => 'Visit our booking website →'],
                ]),
            'Questions? Contact us through '.EmailShared::escapeHtml($brand['bookingSiteUrl']).'.',
            ['preheader' => 'Your password was updated — sign in with your new password']
        );

        return EmailShared::rendered(
            'Your Password Has Been Updated',
            $html,
            implode("\n", [
                "Hello {$name},",
                '',
                "Your {$brand['brandName']} account password has been successfully reset.",
                '',
                'You can now sign in using your new password:',
                $brand['loginUrl'],
                '',
                "If you didn't make this change, please contact our team immediately through our booking website.",
                '',
                'Warm wishes,',
                "The {$brand['brandName']} Team",
                '',
                $brand['brandSiteUrl'],
            ])
        );
    }
}
