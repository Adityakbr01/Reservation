<?php

namespace App\Http\Controllers\API\Public;

use App\Http\Controllers\Controller;
use App\Http\Requests\Availability\SearchAvailabilityRequest;
use App\Models\AvailabilityBlock;
use App\Models\BookingItem;
use App\Models\Room;

class PublicAvailabilityController extends Controller
{
    public function search(SearchAvailabilityRequest $request)
    {
        $data = $request->validated();
        $checkInDate = $data['check_in'];
        $checkOutDate = $data['check_out'];

        $checkIn = \Carbon\Carbon::parse($checkInDate);
        $checkOut = \Carbon\Carbon::parse($checkOutDate);
        $nights = max(1, $checkIn->diffInDays($checkOut));

        $checkInStart = $checkIn->copy()->startOfDay()->format('Y-m-d H:i:s');
        $checkOutStart = $checkOut->copy()->startOfDay()->format('Y-m-d H:i:s');

        // Auto-unhold any expired holds older than 20 minutes
        \App\Models\Booking::unholdExpired();

        // 1. Bulk query: Get all blocked room/room_type IDs in date range with 1 query
        $blockedRoomIds = AvailabilityBlock::where('start_date', '<', $checkOutStart)
            ->where('end_date', '>', $checkInStart)
            ->pluck('room_id')
            ->filter()
            ->all();

        // 2. Bulk query: Get all active booked/held room & room_type IDs in date range with 1 query
        $bookedRoomIds = BookingItem::activeBookings()
            ->where('check_in', '<', $checkOutDate)
            ->where('check_out', '>', $checkInDate)
            ->pluck('room_id')
            ->filter()
            ->all();

        $bookedRoomTypeIds = BookingItem::activeBookings()
            ->where('check_in', '<', $checkOutDate)
            ->where('check_out', '>', $checkInDate)
            ->pluck('room_type_id')
            ->filter()
            ->all();

        $unavailableIds = array_flip(array_merge($blockedRoomIds, $bookedRoomIds, $bookedRoomTypeIds));

        // 3. Bulk query: Get all active cottages with active rate plans in 1 query
        $roomTypes = \App\Models\RoomType::with(['category', 'ratePlans' => function ($q) {
            $q->where('status', 'ACTIVE');
        }])->where('status', 'ACTIVE')->get();

        // 4. Bulk query: Active rooms (Fast read-only, zero redundant writes)
        $roomQuery = Room::where('status', 'ACTIVE');
        if (!empty($data['room_type_id'])) {
            $roomQuery->where('room_type_id', $data['room_type_id']);
        }
        $rooms = $roomQuery->get();

        // Safety fallback: only if rooms table is empty, create initial physical room records
        if ($rooms->isEmpty()) {
            $defaultProp = \App\Models\Property::defaultProperty();
            foreach ($roomTypes as $rt) {
                Room::firstOrCreate(
                    ['room_type_id' => $rt->id],
                    [
                        'id' => bin2hex(random_bytes(12)),
                        'property_id' => $rt->property_id ?? $defaultProp->id,
                        'room_number' => strtoupper(substr($rt->slug ?? 'COT', 0, 3)) . '-1',
                        'name' => $rt->name,
                        'status' => 'ACTIVE',
                    ]
                );
            }
            $rooms = $roomQuery->get();
        }

        $availableCounts = [];
        foreach ($rooms as $room) {
            $isUnavailable = isset($unavailableIds[$room->id]) || isset($unavailableIds[$room->room_type_id]);
            if (! $isUnavailable) {
                $rtId = $room->room_type_id;
                $availableCounts[$rtId] = ($availableCounts[$rtId] ?? 0) + 1;
            }
        }

        $currency = \App\Models\SiteSettings::first()?->currency
            ?? \App\Models\Property::first()?->currency
            ?? 'GBP';

        // 5. Bulk query: Resolve media URLs directly so client has URLs immediately
        $allMediaIds = [];
        foreach ($roomTypes as $rt) {
            foreach ($rt->media ?? [] as $m) {
                $mid = is_array($m) ? ($m['mediaId'] ?? null) : ($m->mediaId ?? null);
                if ($mid) $allMediaIds[] = $mid;
            }
            foreach ($rt->images ?? [] as $img) {
                $mid = is_array($img) ? ($img['mediaId'] ?? null) : ($img->mediaId ?? null);
                if ($mid) $allMediaIds[] = $mid;
            }
            if (!empty($rt->dog_policy_image_media_id)) {
                $allMediaIds[] = (string) $rt->dog_policy_image_media_id;
            }
            $rtExtras = is_array($rt->extras) ? $rt->extras : (is_string($rt->extras) ? (json_decode($rt->extras, true) ?? []) : []);
            foreach ($rtExtras as $extra) {
                $mid = is_array($extra) ? ($extra['imageMediaId'] ?? $extra['image_media_id'] ?? null) : ($extra->imageMediaId ?? null);
                if ($mid) $allMediaIds[] = (string) $mid;
            }
        }
        $mediaMap = [];
        if (!empty($allMediaIds)) {
            $mediaMap = \App\Models\Media::whereIn('id', array_unique($allMediaIds))
                ->get()
                ->keyBy('id');
        }

        $results = [];
        foreach ($roomTypes as $rt) {
            $availableCount = $availableCounts[$rt->id] ?? 0;

            $rates = [];
            $activePlans = $rt->relationLoaded('ratePlans') ? $rt->ratePlans : \App\Models\RatePlan::where('room_type_id', $rt->id)->where('status', 'ACTIVE')->get();
            foreach ($activePlans as $rp) {
                $basePrice = 15000;
                if (is_array($rp->pricing)) {
                    if (isset($rp->pricing['amount']) && is_numeric($rp->pricing['amount'])) {
                        $basePrice = (int) $rp->pricing['amount'];
                    } elseif (isset($rp->pricing['basePrice']) && is_numeric($rp->pricing['basePrice'])) {
                        $basePrice = (int) round(((float) $rp->pricing['basePrice']) * 100);
                    } elseif (isset($rp->pricing['base_price']) && is_numeric($rp->pricing['base_price'])) {
                        $basePrice = (int) round(((float) $rp->pricing['base_price']) * 100);
                    }
                }
                $rates[] = [
                    'ratePlanId' => $rp->id,
                    'name' => $rp->name,
                    'pricingType' => 'PER_NIGHT',
                    'perNight' => $basePrice,
                    'total' => $basePrice * $nights,
                    'currency' => $currency,
                ];
            }

            $resolvedMedia = array_map(function ($m) use ($mediaMap) {
                $item = is_array($m) ? $m : (array) $m;
                $mid = $item['mediaId'] ?? null;
                if ($mid && isset($mediaMap[$mid])) {
                    $item['url'] = $mediaMap[$mid]->url;
                    $item['altText'] = $item['altText'] ?? $mediaMap[$mid]->alt;
                }
                return $item;
            }, $rt->media ?? []);

            $resolvedImages = array_map(function ($img) use ($mediaMap) {
                $item = is_array($img) ? $img : (array) $img;
                $mid = $item['mediaId'] ?? null;
                if ($mid && isset($mediaMap[$mid])) {
                    $item['url'] = $mediaMap[$mid]->url;
                    $item['altText'] = $item['altText'] ?? $mediaMap[$mid]->alt;
                }
                return $item;
            }, $rt->images ?? []);

            $rtDogFees = is_array($rt->dog_fees) ? $rt->dog_fees : (is_string($rt->dog_fees) ? (json_decode($rt->dog_fees, true) ?? []) : []);
            $effectiveMaxDogs = (int) ($rt->max_dogs ?? 0);
            if ($rt->dog_policy_enabled === false) {
                $effectiveMaxDogs = 0;
                $rtDogFees = [];
            } elseif (!empty($rtDogFees)) {
                $maxCustom = max(array_map('intval', array_keys($rtDogFees)));
                $effectiveMaxDogs = max($effectiveMaxDogs, $maxCustom);
            }

            $catId = $rt->category_id ?? ($rt->home_section === 'section_2' ? 'cat_estate_collection' : 'cat_farm_cottages');
            $catObj = null;
            if ($rt->relationLoaded('category') && $rt->category) {
                $catObj = [
                    'id' => $rt->category->id,
                    'name' => $rt->category->name,
                    'slug' => $rt->category->slug,
                    'allowMultiple' => (bool) $rt->category->allow_multiple,
                    'description' => $rt->category->description,
                ];
            } else {
                $isEstate = ($catId === 'cat_estate_collection' || $rt->home_section === 'section_2');
                $catObj = [
                    'id' => $catId,
                    'name' => $isEstate ? 'The Estate Collection' : 'Farm Cottages',
                    'slug' => $isEstate ? 'the-estate-collection' : 'farm-cottages',
                    'allowMultiple' => !$isEstate,
                    'description' => $isEstate ? 'Exclusive estate properties and private retreats.' : 'Charming holiday cottages at Home Farm.',
                ];
            }

            $results[] = [
                'roomType' => [
                    'id' => $rt->id,
                    'name' => $rt->name,
                    'slug' => $rt->slug,
                    'categoryId' => $catId,
                    'category_id' => $catId,
                    'category' => $catObj,
                    'maxAdults' => $rt->max_adults,
                    'maxChildren' => $rt->max_children,
                    'maxOccupancy' => $rt->max_occupancy,
                    'bedrooms' => $rt->bedrooms,
                    'bathrooms' => $rt->bathrooms,
                    'maxDogs' => $effectiveMaxDogs,
                    'max_dogs' => $effectiveMaxDogs,
                    'dogPolicyEnabled' => $rt->dog_policy_enabled === false || $effectiveMaxDogs <= 0 ? false : (bool) ($rt->dog_policy_enabled ?? ($effectiveMaxDogs > 0)),
                    'dog_policy_enabled' => $rt->dog_policy_enabled === false || $effectiveMaxDogs <= 0 ? false : (bool) ($rt->dog_policy_enabled ?? ($effectiveMaxDogs > 0)),
                    'dogPolicyTitle' => $rt->dog_policy_title,
                    'dog_policy_title' => $rt->dog_policy_title,
                    'dogPolicySubtitle' => $rt->dog_policy_subtitle,
                    'dog_policy_subtitle' => $rt->dog_policy_subtitle,
                    'dogFee' => $rt->dog_fee !== null ? (float) $rt->dog_fee : 70.00,
                    'dog_fee' => $rt->dog_fee !== null ? (float) $rt->dog_fee : 70.00,
                    'dogFees' => $rtDogFees,
                    'dog_fees' => $rtDogFees,
                    'dogPolicyImageMediaId' => $rt->dog_policy_image_media_id,
                    'dog_policy_image_media_id' => $rt->dog_policy_image_media_id,
                    'dogPolicyImageUrl' => (!empty($rt->dog_policy_image_media_id) && isset($mediaMap[$rt->dog_policy_image_media_id])) ? $mediaMap[$rt->dog_policy_image_media_id]->url : null,
                    'dog_policy_image_url' => (!empty($rt->dog_policy_image_media_id) && isset($mediaMap[$rt->dog_policy_image_media_id])) ? $mediaMap[$rt->dog_policy_image_media_id]->url : null,
                    'shortDescription' => $rt->short_description,
                    'homeSection' => $rt->home_section ?? ($rt->section_settings['home_section'] ?? 'section_1'),
                    'home_section' => $rt->home_section ?? ($rt->section_settings['home_section'] ?? 'section_1'),
                    'sectionSettings' => $rt->section_settings ?? [],
                    'section_settings' => $rt->section_settings ?? [],
                    'amenities' => $rt->amenities ?? [],
                    'images' => $resolvedImages,
                    'media' => $resolvedMedia,
                    'extras' => array_map(function ($extra) use ($mediaMap) {
                        $ex = is_array($extra) ? $extra : (array) $extra;
                        $mid = $ex['imageMediaId'] ?? $ex['image_media_id'] ?? null;
                        if ($mid) {
                            $midStr = (string) $mid;
                            if (isset($mediaMap[$midStr])) {
                                $ex['imageUrl'] = $mediaMap[$midStr]->url;
                                $ex['image_url'] = $mediaMap[$midStr]->url;
                            } else {
                                $med = \App\Models\Media::find($midStr);
                                if ($med) {
                                    $ex['imageUrl'] = $med->url;
                                    $ex['image_url'] = $med->url;
                                }
                            }
                        }
                        return $ex;
                    }, is_array($rt->extras) ? $rt->extras : (is_string($rt->extras) ? (json_decode($rt->extras, true) ?? []) : [])),
                ],
                'availableCount' => $availableCount,
                'rates' => $rates,
            ];
        }

        return response()->json([
            'success' => true,
            'data' => [
                'results' => $results,
                'search' => [
                    'checkIn' => $data['check_in'],
                    'checkOut' => $data['check_out'],
                    'adults' => (int) ($data['adults'] ?? 2),
                    'children' => (int) ($data['children'] ?? 0),
                    'rooms' => (int) ($data['rooms'] ?? 1),
                    'nights' => $nights,
                ],
            ],
        ]);
    }

    public function calendar(\Illuminate\Http\Request $request)
    {
        // Auto-unhold any expired holds older than 20 minutes
        \App\Models\Booking::unholdExpired();

        $now = \Carbon\Carbon::now();
        $from = $request->query('from') ?? $now->copy()->startOfMonth()->toDateString();
        $to = $request->query('to') ?? $now->copy()->endOfMonth()->toDateString();
        $roomTypeId = $request->query('roomTypeId') ?? $request->query('room_type_id');

        try {
            $startDate = \Carbon\Carbon::parse($from);
            $endDate = \Carbon\Carbon::parse($to);
        } catch (\Throwable) {
            $startDate = $now->copy()->startOfMonth();
            $endDate = $now->copy()->endOfMonth();
            $from = $startDate->toDateString();
            $to = $endDate->toDateString();
        }

        $query = \App\Models\RoomType::where('status', 'ACTIVE');
        if ($roomTypeId && $roomTypeId !== 'all') {
            $query->where('id', $roomTypeId);
        }
        $roomTypes = $query->get();

        $minStayConfig = (int) (\App\Models\SiteSettings::first()?->minimum_stay_nights ?? 2);
        if ($minStayConfig < 1) {
            $minStayConfig = 2;
        }

        // 1. Bulk query active rooms for all room types
        $allRooms = Room::where('status', 'ACTIVE')->get()->groupBy('room_type_id');
        $allRoomIds = $allRooms->flatten()->pluck('id')->map(fn ($id) => (string) $id)->all();
        $allRoomTypeIds = $roomTypes->pluck('id')->map(fn ($id) => (string) $id)->all();

        // 2. Bulk query AvailabilityBlock in date range with 1 single query
        $rangeStartStr = $startDate->copy()->startOfDay()->format('Y-m-d H:i:s');
        $rangeEndStr = $endDate->copy()->addDay()->startOfDay()->format('Y-m-d H:i:s');
        $rangeStartDateStr = $startDate->toDateString();
        $rangeEndDateStr = $endDate->copy()->addDay()->toDateString();

        $allBlocks = AvailabilityBlock::where(function ($q) use ($allRoomIds, $allRoomTypeIds) {
                $q->whereIn('room_id', $allRoomIds)
                  ->orWhereIn('room_id', $allRoomTypeIds);
            })
            ->where('start_date', '<', $rangeEndStr)
            ->where('end_date', '>', $rangeStartStr)
            ->get(['room_id', 'start_date', 'end_date']);

        // 3. Bulk query active BookingItems in date range with 1 single query
        $allBookings = BookingItem::activeBookings()
            ->where(function ($q) use ($allRoomIds, $allRoomTypeIds) {
                $q->whereIn('room_id', $allRoomIds)
                  ->orWhereIn('room_type_id', $allRoomTypeIds);
            })
            ->where('check_in', '<', $rangeEndDateStr)
            ->where('check_out', '>', $rangeStartDateStr)
            ->get(['room_id', 'room_type_id', 'check_in', 'check_out']);

        // Pre-convert blocks & bookings to integer timestamps for ultra-fast in-memory matching
        $parsedBlocks = [];
        foreach ($allBlocks as $b) {
            $sTs = strtotime((string) $b->start_date);
            $eTs = strtotime((string) $b->end_date);
            if ($sTs && $eTs) {
                $parsedBlocks[] = [
                    'room_id' => (string) $b->room_id,
                    'start' => $sTs,
                    'end' => $eTs,
                ];
            }
        }

        $parsedBookings = [];
        foreach ($allBookings as $bi) {
            $sTs = strtotime((string) $bi->check_in);
            $eTs = strtotime((string) $bi->check_out);
            if ($sTs && $eTs) {
                $parsedBookings[] = [
                    'room_id' => $bi->room_id ? (string) $bi->room_id : null,
                    'room_type_id' => $bi->room_type_id ? (string) $bi->room_type_id : null,
                    'start' => $sTs,
                    'end' => $eTs,
                ];
            }
        }

        $typesData = [];
        foreach ($roomTypes as $rt) {
            $rtId = (string) $rt->id;
            $rooms = $allRooms->get($rtId, collect());
            if ($rooms->isEmpty()) {
                $room = Room::firstOrCreate(
                    ['room_type_id' => $rt->id],
                    [
                        'id' => bin2hex(random_bytes(12)),
                        'property_id' => $rt->property_id,
                        'room_number' => $rt->slug ?: '1',
                        'name' => $rt->name,
                        'status' => 'ACTIVE',
                    ]
                );
                $rooms = collect([$room]);
            }
            $totalRooms = max(1, $rooms->count());
            $roomIds = $rooms->pluck('id')->map(fn ($id) => (string) $id)->all();
            $targetKeys = array_flip(array_merge([$rtId], $roomIds));

            // Pre-filter records for this specific room type
            $rtBlocks = [];
            foreach ($parsedBlocks as $pb) {
                if (isset($targetKeys[$pb['room_id']])) {
                    $rtBlocks[] = [$pb['start'], $pb['end']];
                }
            }

            $rtBookings = [];
            foreach ($parsedBookings as $pbi) {
                if (($pbi['room_id'] && isset($targetKeys[$pbi['room_id']])) || ($pbi['room_type_id'] === $rtId)) {
                    $rtBookings[] = [$pbi['start'], $pbi['end']];
                }
            }

            $days = [];
            $cursor = $startDate->copy();
            // Generous limit up to 730 days (2 full years) for unlimited month grid
            $limit = 0;
            while ($cursor->lte($endDate) && $limit < 730) {
                $limit++;
                $curDate = $cursor->toDateString();
                $nextDate = $cursor->copy()->addDay()->toDateString();
                $curTs = strtotime($curDate);
                $nextTs = strtotime($nextDate);

                $blockedCount = 0;
                $bookedCount = 0;

                if ($totalRooms > 0) {
                    foreach ($rtBlocks as [$bStart, $bEnd]) {
                        if ($bStart < $nextTs && $bEnd > $curTs) {
                            $blockedCount++;
                        }
                    }

                    foreach ($rtBookings as [$bkStart, $bkEnd]) {
                        if ($bkStart < $nextTs && $bkEnd > $curTs) {
                            $bookedCount++;
                        }
                    }
                }

                $availableCount = max(0, $totalRooms - $blockedCount - $bookedCount);

                $days[] = [
                    'date' => $curDate,
                    'total' => $totalRooms,
                    'available' => $availableCount,
                    'booked' => $bookedCount,
                    'blocked' => $blockedCount,
                    'minNights' => $minStayConfig,
                ];

                $cursor->addDay();
            }

            $typesData[] = [
                'roomTypeId' => $rtId,
                'name' => (string) $rt->name,
                'days' => $days,
            ];
        }

        return response()->json([
            'success' => true,
            'data' => [
                'from' => $from,
                'to' => $to,
                'types' => $typesData,
            ],
        ]);
    }
}
